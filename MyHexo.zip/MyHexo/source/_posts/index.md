---
title: 生活不仅仅只有今天的苟且，还有明天。。。
---

<img src="./img/yuanfang.jpg" width = "1300" height = "867" alt="yuanfang" align=center />